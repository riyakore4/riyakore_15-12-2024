document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();
});

function fetchProducts() {
    fetch("server.php?action=fetch")
        .then((response) => response.json())
        .then((data) => {
            const productList = document.getElementById("product-list");
            productList.innerHTML = data.map(productToHTML).join("");
        });
}

function productToHTML(product) {
    return `
    <div class="col-md-4">
        <div class="card product-card">
            <div class="card-body">
                <h5 class="card-title">${product.name}</h5>
                <p class="card-text">RS.${product.price}</p>
                <p>${product.description}</p>
                <button class="btn btn-danger" onclick="deleteProduct(${product.id})">Delete</button>
            </div>
        </div>
    </div>`;
}

function deleteProduct(id) {
    fetch(`server.php?action=delete&id=${id}`)
        .then(() => fetchProducts());
}
