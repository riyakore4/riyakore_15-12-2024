<?php
//Database connection by using xampp mysql
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'product_catalog';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
    $action = $_GET['action'];

    if ($action === 'fetch') {
        fetchProducts();
    } elseif ($action === 'delete' && isset($_GET['id'])) {
        deleteProduct($_GET['id']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'add') {
        addProduct($_POST['name'], $_POST['price'], $_POST['description']);
    }
}


function fetchProducts()
{
    global $conn;
    $sql = "SELECT * FROM products";
    $result = $conn->query($sql);

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }

    echo json_encode($products);
}


function addProduct($name, $price, $description)
{
    global $conn;
    $sql = "INSERT INTO products (name, price, description) VALUES ('$name', '$price', '$description')";
    if ($conn->query($sql)) {
        header("Location: index.html");
    } else {
        echo "Error: " . $conn->error;
    }
}


function deleteProduct($id)
{
    global $conn;
    $sql = "DELETE FROM products WHERE id = $id";
    if ($conn->query($sql)) {
        echo "Product deleted";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
